#include "AssassinMeleeAttackSpell.h"

AssassinMeleeAttackSpell::AssassinMeleeAttackSpell()
{
	type = MELEE;
	aoe = ASSASSIN_MELEE_ATTACK_AOE;
	damage = ASSASSIN_MELEE_ATTACK_DAMAGE;
	slowPercentage = ASSASSIN_MELEE_SLOW_PERCENTAGE;
	cooldown = ASSASSIN_MELEE_ATTACK_COOLDOWN;
}