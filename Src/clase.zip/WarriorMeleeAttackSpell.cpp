#include "WarriorMeleeAttackSpell.h"

WarriorMeleeAttackSpell::WarriorMeleeAttackSpell()
{
	type = MELEE;
	aoe = WARRIOR_MELEE_ATTACK_AOE;
	damage = WARRIOR_MELEE_ATTACK_DAMAGE;
	slowPercentage = WARRIOR_MELEE_SLOW_PERCENTAGE;
	cooldown = WARRIOR_MELEE_ATTACK_COOLDOWN;
}