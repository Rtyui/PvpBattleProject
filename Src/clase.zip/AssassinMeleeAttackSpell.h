#include <stdio.h>
#include "Spell.h"

class AssassinMeleeAttackSpell : public Spell
{
public:
	AssassinMeleeAttackSpell();
	~AssassinMeleeAttackSpell();
private:
	/* Area of effect of this spell */
	int aoe;
};