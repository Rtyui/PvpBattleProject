#include "Wizard.h"

Wizard::Wizard()
{
	hp = WIZARD_HP;
	mp = WIZARD_MP;
	moveSpeed = WIZARD_MOVESPEED;
	spells = new std::vector<SPTR>(SPELL_NUMBER);
	spells->at(0) = new RangedAttackSpell();
}

Wizard::Wizard()
{
	for (int i = 0; i < SPELL_NUMBER; i++)
		delete(spells->at(i));
	delete(spells);
}