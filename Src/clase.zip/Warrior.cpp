#include "Warrior.h"

Warrior::Warrior()
{
	hp = WARRIOR_HP;
	mp = WARRIOR_MP;
	moveSpeed = WARRIOR_MOVESPEED;
	spells = new std::vector<SPTR>(SPELL_NUMBER);
	spells->at(0) = new WarriorMeleeAttackSpell();
}

Warrior::~Warrior()
{
	for (int i = 0; i < SPELL_NUMBER; i++)
		delete(spells->at(i));
	delete(spells);
}