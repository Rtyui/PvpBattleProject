#include <stdio.h>
#include "Character.h"
#include "WarriorMeleeAttackSpell.h"

class Warrior : public Character
{
public:
	Warrior();
	~Warrior();
private:
};