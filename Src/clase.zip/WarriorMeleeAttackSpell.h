#include <stdio.h>
#include "Spell.h"

class WarriorMeleeAttackSpell : public Spell 
{
public:
	WarriorMeleeAttackSpell();
	~WarriorMeleeAttackSpell();
private:
	/* Area of effect of this spell */
	int aoe;
};