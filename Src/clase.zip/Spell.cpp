#include <stdio.h>
#include "Spell.h"

Spell::Spell()
{
	damage = 0;
	projectileSpeed = BASE_PROJECTILE_SPEED;
	slowPercentage = 0;
}

Spell::Spell(int damage) : damage(damage)
{
	projectileSpeed = BASE_PROJECTILE_SPEED;
	slowPercentage = 0;
}

Spell::Spell(int damage, int speed, int percent) : 
	damage(damage),
	projectileSpeed(speed),
	slowPercentage(percent) {}

Spell::~Spell() {}
