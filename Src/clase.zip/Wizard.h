#include "Character.h"
#include "RangedAttackSpell.h"

class Wizard : public Character
{
public:
	Wizard();
	~Wizard();
};