#pragma once
#include <stdio.h>

#define BASE_PROJECTILE_SPEED					100

#define RANGED_ATTACK_DAMAGE					30
#define RANGED_ATTACK_COOLDOWN					4
#define RANGED_ATTACK_SLOW_PERCENTAGE			0

#define WARRIOR_MELEE_ATTACK_AOE				50
#define WARRIOR_MELEE_ATTACK_DAMAGE				150
#define WARRIOR_MELEE_SLOW_PERCENTAGE			0
#define WARRIOR_MELEE_ATTACK_COOLDOWN			3

#define ASSASSIN_MELEE_ATTACK_AOE				50
#define ASSASSIN_MELEE_ATTACK_DAMAGE			110
#define ASSASSIN_MELEE_SLOW_PERCENTAGE			3
#define ASSASSIN_MELEE_ATTACK_COOLDOWN			4

enum STYPE {
	PROJECTILE_APPLY_ON_CHARACTER,
	PROJECTILE_APPLY_ON_ENVIROMENT,
	MELEE
};

class Spell
{
public:
	Spell();
	Spell(int damage);
	Spell(int damage, int percent);
	Spell(int damage, int speed, int percent);
	~Spell();

protected:
	/* Type of spell */
	STYPE type;

	/* Damage this spell inflicts upon enemy */
	int damage;

	/* Projectile speed */
	int projectileSpeed;

	/* Slow percentage applied on enemy */
	int slowPercentage;

	/* Time between repeated uses of this spell */
	int cooldown;
};