#include "RangedAttackSpell.h"

RangedAttackSpell::RangedAttackSpell()
{
	type = PROJECTILE_APPLY_ON_CHARACTER;
	damage = RANGED_ATTACK_DAMAGE;
	projectileSpeed = BASE_PROJECTILE_SPEED;
	slowPercentage = RANGED_ATTACK_SLOW_PERCENTAGE;
	cooldown = RANGED_ATTACK_COOLDOWN;
}

RangedAttackSpell::RangedAttackSpell() {}