#include "Character.h"
#include "AssassinMeleeAttackSpell.h"

class Assassin : public Character
{
public:
	Assassin();
	~Assassin();
private:
};