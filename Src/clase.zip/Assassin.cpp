#include "Assassin.h"

Assassin::Assassin()
{
	hp = ASSASSIN_HP;
	mp = ASSASSIN_MP;
	moveSpeed = ASSASSIN_MOVESPEED;
	spells = new std::vector<SPTR>(SPELL_NUMBER);
	spells->at(0) = new AssassinMeleeAttackSpell();
}

Assassin::~Assassin()
{
	for (int i = 0; i < SPELL_NUMBER; i++)
		delete(spells->at(i));
	delete(spells);
}